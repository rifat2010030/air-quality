// Wait for DOM to be fully loaded before running the script
document.addEventListener('DOMContentLoaded', function() {
    // Add a small delay to ensure all elements are fully rendered
    setTimeout(function() {
        let currentRunNo = 1;
        let runNoToFileMap = {}; // Map for storing files by Run No.
        let selectedColumns = []; // To store selected columns for deletion
        let initializationFile = null; // For storing the initialization CSV file
        let smoothedDataCache = null; // To store smoothed data for range plotting
 
    // ----------------------------
    // Notifications
    // ----------------------------
    function showNotification(message, type = "") {
        const notification = document.createElement("div");
        notification.classList.add("notification");
        if (type === "error") notification.classList.add("error");
        if (type === "add") notification.classList.add("notification-add");
        notification.textContent = message;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 3000);
    }
 
    // ----------------------------
    // Experimental Run Table: Upload and Populate
    // ----------------------------
    document.getElementById("project-directory").addEventListener("change", function (event) {
        const file = event.target.files[0];
        if (file && file.name.endsWith(".csv")) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const content = e.target.result;
                const rows = content.split("\n").map(row => row.split(","));
                populateTable(rows);
            };
            reader.readAsText(file);
        } else {
            alert("Please upload a valid CSV file.");
        }
    });
 
    function populateTable(rows) {
        const tableBody = document.getElementById("results-table").getElementsByTagName("tbody")[0];
        tableBody.innerHTML = "";
 
        rows.forEach((row, index) => {
            const newRow = tableBody.insertRow();
            const serialNoCell = newRow.insertCell(0);
            serialNoCell.textContent = index + 1;
 
            const csvFileCell = newRow.insertCell(1);
            const fileInput = document.createElement("input");
            fileInput.type = "file";
            fileInput.accept = ".csv";
            fileInput.addEventListener("change", (event) => handleFileUpload(event, index));
            csvFileCell.appendChild(fileInput);
 
            const columns = [
                "Breakwater Name", "Breakwater Width", "Breakwater Length",
                "Breakwater Height", "Breakwater Draft", "Wave Period",
                "Wave Height", "Wave Length Measured"
            ];
 
            columns.forEach((_, i) => {
                const cell = newRow.insertCell(i + 2);
                cell.contentEditable = true;
                cell.textContent = row[i] || "";
            });
 
            for (let i = 8; i < row.length; i++) {
                const extraParamCell = newRow.insertCell(i + 2);
                extraParamCell.contentEditable = true;
                extraParamCell.textContent = row[i] || "";
            }
        });
    }
 
    function handleFileUpload(event, rowIndex) {
        const file = event.target.files[0];
        const fileNameCell = event.target.closest("td");
        if (file && file.name.endsWith(".csv")) {
            fileNameCell.textContent = file.name;
            const tableBody = document.getElementById("results-table").getElementsByTagName("tbody")[0];
            const runNo = tableBody.rows[rowIndex].cells[0].textContent.trim();
            runNoToFileMap[runNo] = file;
 
            const reader = new FileReader();
            reader.onload = (e) => {
                console.log(`CSV uploaded for row ${rowIndex}:`, e.target.result);
                showNotification(`File uploaded successfully for Row ${parseInt(runNo)}`);
            };
            reader.readAsText(file);
        } else {
            alert("Please upload a valid CSV file.");
        }
    }
 
    // ----------------------------
    // Experimental Run Table Actions
    // ----------------------------
    document.getElementById("add-row-btn").addEventListener("click", function () {
        const tableBody = document.getElementById("results-table").getElementsByTagName("tbody")[0];
        const newRow = tableBody.insertRow();
 
        const serialNoCell = newRow.insertCell(0);
        serialNoCell.textContent = tableBody.rows.length;
 
        const csvFileCell = newRow.insertCell(1);
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".csv";
        fileInput.addEventListener("change", (event) => handleFileUpload(event, tableBody.rows.length - 1));
        csvFileCell.appendChild(fileInput);
 
        const numExistingColumns = 8;
        for (let i = 0; i < numExistingColumns; i++) {
            const newCell = newRow.insertCell(i + 2);
            newCell.contentEditable = true;
            newCell.textContent = "";
        }
 
        const extraColumnCount = document.querySelectorAll("#results-table th").length - 11;
        for (let i = 0; i < extraColumnCount; i++) {
            const extraParamCell = newRow.insertCell(numExistingColumns + i + 2);
            extraParamCell.contentEditable = true;
            extraParamCell.textContent = "";
        }
 
        showNotification("Row added successfully!");
    });
 
    // Save as CSV Button
    window.saveCSV = function() {
        const table = document.getElementById("results-table");
        const rows = table.rows;
        let csvContent = "";
 
        csvContent += Array.from(rows[0].cells).map(cell => cell.textContent).join(",") + "\n";
        for (let i = 1; i < rows.length; i++) {
            const row = Array.from(rows[i].cells).map(cell => cell.textContent).join(",");
            csvContent += row + "\n";
        }
 
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "results.csv";
        link.click();
    }
 
    // Clear Table Button
    document.getElementById("clear-table-btn").addEventListener("click", function () {
        document.getElementById("results-table").getElementsByTagName("tbody")[0].innerHTML = "";
    });
 
    // Add Extra Parameter Column Button
    document.getElementById("add-extra-column").addEventListener("click", function () {
        const table = document.getElementById("results-table");
        const header = table.querySelector("thead tr");
        const newHeaderCell = document.createElement("th");
        newHeaderCell.contentEditable = true;
        newHeaderCell.textContent = "Extra Parameter " + (header.children.length - 10);
        header.appendChild(newHeaderCell);
 
        const rows = table.querySelectorAll("tbody tr");
        rows.forEach(row => {
            const newCell = row.insertCell(-1);
            newCell.contentEditable = true;
        });
 
        showNotification("Extra Parameter column added!", "add");
    });
 
    // Delete Selected Columns Button
    document.getElementById("delete-columns").addEventListener("click", function () {
        if (selectedColumns.length > 0) {
            const table = document.getElementById("results-table");
            const rows = table.querySelectorAll("tr");
            selectedColumns.sort((a, b) => b - a);
 
            rows.forEach(row => {
                selectedColumns.forEach(colIndex => {
                    row.deleteCell(colIndex);
                });
            });
 
            selectedColumns = [];
            document.querySelectorAll("th.selected").forEach(th => th.classList.remove("selected"));
            showNotification("Selected columns deleted!");
        } else {
            alert("Please select columns using Ctrl+Click.");
        }
    });
 
    // Handle column selection for deletion
    setTimeout(() => {
        document.querySelectorAll("#results-table th").forEach((header, index) => {
            header.addEventListener("click", (event) => {
                if (event.ctrlKey || event.metaKey) {
                    if (selectedColumns.includes(index)) {
                        selectedColumns = selectedColumns.filter(i => i !== index);
                        header.classList.remove("selected");
                    } else {
                        selectedColumns.push(index);
                        header.classList.add("selected");
                    }
                } else {
                    selectedColumns = [index];
                    document.querySelectorAll("th").forEach(th => th.classList.remove("selected"));
                    header.classList.add("selected");
                }
            });
        });
    }, 100);
 
    // Toggle buttons
    document.getElementById("toggle-table-btn").addEventListener("click", function () {
        const table = document.getElementById("results-table");
        table.style.display = (table.style.display === "none") ? "table" : "none";
    });
 
    document.getElementById("toggle-wave-gauge-table").addEventListener("click", function () {
        const table = document.getElementById("spreadsheet");
        table.style.display = (table.style.display === "none") ? "table" : "none";
    });
 
    // Download CSV from Wave Gauge Data Table
    document.getElementById("download-csv-btn").addEventListener("click", function () {
        const table = document.getElementById("spreadsheet");
        const rows = table.querySelectorAll("tr");
 
        let csvContent = "";
        rows.forEach(row => {
            const rowData = [];
            const cells = row.querySelectorAll("td, th");
            cells.forEach(cell => {
                rowData.push(cell.textContent.trim());
            });
            csvContent += rowData.join(",") + "\n";
        });
 
        const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "wave_gauge_data.csv";
        link.click();
    });
 
    // ----------------------------
    // Wave Gauge Data Functions
    // ----------------------------
    function loadSpreadsheetData(runNo) {
        const file = runNoToFileMap[runNo];
 
        if (!file) {
            showNotification(`No CSV file uploaded for Run No. ${runNo}`, "error");
            return;
        }
 
        const reader = new FileReader();
        reader.onload = function (e) {
            const csvText = e.target.result.trim();
            const csvRows = csvText.split("\n").map(row => row.split(","));
            populateSpreadsheet(csvRows);
            generateGraphs(csvRows);
            showNotification(`Loaded CSV for Run No. ${runNo}`);
        };
 
        reader.readAsText(file);
    }
 
    function populateSpreadsheet(data) {
        const tbody = document.querySelector("#spreadsheet tbody");
        tbody.innerHTML = "";
        data.forEach(row => {
            const tr = document.createElement("tr");
            row.forEach(cell => {
                const td = document.createElement("td");
                td.contentEditable = true;
                td.textContent = cell;
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
    }
 
    function generateGraphs(data) {
        let canvasExists = true;
        for (let i = 1; i <= 10; i++) {
            if (!document.getElementById(`graph${i}`)) {
                console.warn(`Canvas element graph${i} not found`);
                canvasExists = false;
            }
        }
 
        if (!canvasExists) {
            showNotification("Some graph canvas elements are missing. Graphs may not display correctly.", "error");
            return;
        }
 
        generateWaveGraph(data, 0, 1, "graph1", "Wave Height1 vs Time 1 (ms)");
        generateWaveGraph(data, 2, 3, "graph2", "Wave Height2 vs Time 2 (ms)");
        generateWaveGraph(data, 4, 5, "graph3", "Wave Height3 vs Time 3 (ms)");
        generateWaveGraph(data, 6, 7, "graph4", "Wave Height4 vs Time 4 (ms)");
        generateWaveGraph(data, 8, 9, "graph5", "Wave Height5 vs Time 5 (ms)");
        generateWaveGraph(data, 0, 1, "graph6", "Wave Height1 vs Time 1 (sec)", true);
        generateWaveGraph(data, 2, 3, "graph7", "Wave Height2 vs Time 2 (sec)", true);
        generateWaveGraph(data, 4, 5, "graph8", "Wave Height3 vs Time 3 (sec)", true);
        generateWaveGraph(data, 6, 7, "graph9", "Wave Height4 vs Time 4 (sec)", true);
        generateWaveGraph(data, 8, 9, "graph10", "Wave Height5 vs Time 5 (sec)", true);
    }
 
    function generateWaveGraph(data, timeIndex, waveHeightIndex, graphId, label, convertToSeconds = false) {
        const canvas = document.getElementById(graphId);
        if (!canvas) {
            console.error(`Canvas element with ID ${graphId} not found`);
            return;
        }
 
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            console.error(`Could not get context for canvas ${graphId}`);
            return;
        }
 
        const timeData = [];
        const waveHeightData = [];
 
        data.forEach((row) => {
            if (row.length <= timeIndex || row.length <= waveHeightIndex) {
                return;
            }
 
            const time = parseFloat(row[timeIndex]);
            const waveHeight = parseFloat(row[waveHeightIndex]);
 
            if (!isNaN(time) && !isNaN(waveHeight)) {
                timeData.push(convertToSeconds ? time / 1000 : time);
                waveHeightData.push(waveHeight);
            }
        });
 
        if (canvas.chart) {
            canvas.chart.destroy();
        }
 
        canvas.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: timeData,
                datasets: [{
                    label: label,
                    data: waveHeightData,
                    borderColor: 'blue',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    fill: false,
                    tension: 0.1,
                    pointRadius: 2,
                    borderWidth: 0.5
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: { 
                            display: true, 
                            text: convertToSeconds ? 'Time (sec)' : 'Time (ms)' 
                        }
                    },
                    y: {
                        title: { 
                            display: true, 
                            text: 'Wave Height' 
                        }
                    }
                }
            }
        });
    }
 
    // Time in Seconds Button
    document.getElementById("time-in-seconds-btn").addEventListener("click", function () {
        const table = document.getElementById("spreadsheet");
        const rows = table.querySelectorAll("tbody tr");
 
        rows.forEach(row => {
            for (let i = 0; i < row.cells.length; i++) {
                const cell = row.cells[i];
                if (i % 2 === 0) {
                    const timeInMillis = parseFloat(cell.textContent);
                    if (!isNaN(timeInMillis)) {
                        cell.textContent = (timeInMillis / 1000).toFixed(3);
                    }
                }
            }
        });
 
        showNotification("Time converted to seconds in the table!");
    });
 
    // Initialization Button
    document.getElementById("initialization-btn").addEventListener("click", function () {
        const table = document.getElementById("spreadsheet");
        const rows = table.querySelectorAll("tbody tr");
 
        for (let colIndex = 0; colIndex < 10; colIndex += 2) {
            const firstTimeCell = rows[0].cells[colIndex];
            const firstTimeValue = parseFloat(firstTimeCell.textContent);
 
            if (isNaN(firstTimeValue)) {
                showNotification(`First time cell in column ${colIndex + 1} is not a valid number.`, "error");
                return;
            }
 
            rows.forEach(row => {
                const timeCell = row.cells[colIndex];
                const timeValue = parseFloat(timeCell.textContent);
 
                if (!isNaN(timeValue)) {
                    const newTimeValue = ((timeValue - firstTimeValue) / 1000).toFixed(3);
                    timeCell.textContent = newTimeValue;
                }
            });
        }
 
        showNotification("Time values initialized for each column and converted to seconds!");
    });
 
    // Navigation Buttons
    document.getElementById("go-btn").addEventListener("click", () => {
        const val = document.getElementById("run-no").value;
        if (val) {
            currentRunNo = parseInt(val);
            loadSpreadsheetData(currentRunNo);
        }
    });
 
    document.getElementById("prev-run").addEventListener("click", () => {
        if (currentRunNo > 1) {
            currentRunNo--;
            document.getElementById("run-no").value = currentRunNo;
            loadSpreadsheetData(currentRunNo);
        }
    });
 
    document.getElementById("next-run").addEventListener("click", () => {
        currentRunNo++;
        document.getElementById("run-no").value = currentRunNo;
        loadSpreadsheetData(currentRunNo);
    });

    // ----------------------------
    // Initialization CSV Upload
    // ----------------------------
    document.getElementById("initialization-csv").addEventListener("change", function (event) {
        const file = event.target.files[0];
        if (file && file.name.endsWith(".csv")) {
            initializationFile = file;
            const reader = new FileReader();
            reader.onload = function (e) {
                const content = e.target.result;
                const rows = content.split("\n").map(row => row.split(","));
                populateInitializationTable(rows);
            };
            reader.readAsText(file);
        } else {
            alert("Please upload a valid Initialization CSV file.");
        }
    });

    function populateInitializationTable(rows) {
        const tableBody = document.getElementById("initialization-table").getElementsByTagName("tbody")[0];
        tableBody.innerHTML = "";

        rows.forEach(row => {
            const newRow = tableBody.insertRow();
            for (let i = 0; i < row.length; i++) {
                const cell = newRow.insertCell(i);
                cell.contentEditable = true;
                cell.textContent = row[i] || "";
            }
        });

        showNotification("Initialization data uploaded successfully!");
        generateInitializationGraphs(rows);
        
        // Also generate outlier-removed graphs automatically
        removeOutliersAndRenderGraphs();
    }

    // Initialization Graphs
    function generateInitializationGraphs(data) {
        window.requestAnimationFrame(() => {
            const datasets = [
                { timeIndex: 0, heightIndex: 1, graphId: 'initialization-graph1', label: 'Wave Gauge 1 vs Initialization Time 1 (sec)' },
                { timeIndex: 2, heightIndex: 3, graphId: 'initialization-graph2', label: 'Wave Gauge 2 vs Initialization Time 2 (sec)' },
                { timeIndex: 4, heightIndex: 5, graphId: 'initialization-graph3', label: 'Wave Gauge 3 vs Initialization Time 3 (sec)' },
                { timeIndex: 6, heightIndex: 7, graphId: 'initialization-graph4', label: 'Wave Gauge 4 vs Initialization Time 4 (sec)' },
                { timeIndex: 8, heightIndex: 9, graphId: 'initialization-graph5', label: 'Wave Gauge 5 vs Initialization Time 5 (sec)' }
            ];

            datasets.forEach(dataset => {
                const timeData = [];
                const heightData = [];

                data.forEach(row => {
                    if (row.length > dataset.timeIndex && row.length > dataset.heightIndex) {
                        const time = parseFloat(row[dataset.timeIndex]);
                        const height = parseFloat(row[dataset.heightIndex]);

                        if (!isNaN(time) && !isNaN(height)) {
                            timeData.push(time);
                            heightData.push(height);
                        }
                    }
                });

                createInitializationGraph(dataset.graphId, dataset.label, timeData, heightData);
            });
        });
    }

    function createInitializationGraph(graphId, label, timeData, heightData) {
        const canvas = document.getElementById(graphId);
        if (!canvas) {
            console.warn(`Canvas element ${graphId} not found`);
            return;
        }

        const ctx = canvas.getContext('2d');
        if (!ctx) {
            console.warn(`Could not get context for canvas ${graphId}`);
            return;
        }

        if (canvas.chart) {
            canvas.chart.destroy();
        }

        canvas.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: timeData,
                datasets: [{
                    label: label,
                    data: heightData,
                    borderColor: 'blue',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    fill: false,
                    tension: 0.1,
                    pointRadius: 2,
                    borderWidth: 0.5
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: { display: true, text: 'Initialization Time (sec)' }
                    },
                    y: {
                        title: { display: true, text: 'Wave Height (cm)' }
                    }
                }
            }
        });
    }

    // Apply advanced smoothing for smooth plot
    function applySmoothingForSmoothPlot(data) {
        if (data.length < 3) return data;
        
        // Apply multiple smoothing passes
        let smoothed = [...data];
        
        // First pass: Savitzky-Golay filter (simplified version)
        smoothed = applySavitzkyGolayFilter(smoothed);
        
        // Second pass: Gaussian smoothing
        smoothed = applyGaussianSmoothing(smoothed);
        
        return smoothed;
    }

    // Savitzky-Golay filter for smoothing
    function applySavitzkyGolayFilter(data) {
        if (data.length < 5) return data;
        
        const smoothed = [...data];
        const windowSize = 5;
        const coefficients = [-3, 12, 17, 12, -3];
        const sum = 35;
        
        for (let i = 2; i < data.length - 2; i++) {
            let weightedSum = 0;
            for (let j = -2; j <= 2; j++) {
                weightedSum += data[i + j] * coefficients[j + 2];
            }
            smoothed[i] = weightedSum / sum;
        }
        
        return smoothed;
    }

    // Gaussian smoothing
    function applyGaussianSmoothing(data, windowSize = 5) {
        if (data.length < windowSize) return data;
        
        const smoothed = [...data];
        const sigma = windowSize / 3;
        let kernel = [];
        let sum = 0;
        
        // Generate Gaussian kernel
        for (let i = -Math.floor(windowSize/2); i <= Math.floor(windowSize/2); i++) {
            const val = Math.exp(-i*i / (2*sigma*sigma)) / (sigma * Math.sqrt(2*Math.PI));
            kernel.push(val);
            sum += val;
        }
        
        // Normalize kernel
        kernel = kernel.map(k => k / sum);
        
        // Apply kernel
        for (let i = Math.floor(windowSize/2); i < data.length - Math.floor(windowSize/2); i++) {
            let smoothValue = 0;
            for (let j = -Math.floor(windowSize/2); j <= Math.floor(windowSize/2); j++) {
                smoothValue += data[i + j] * kernel[j + Math.floor(windowSize/2)];
            }
            smoothed[i] = smoothValue;
        }
        
        return smoothed;
    }

    // New function for selective spike removal while preserving wave patterns
    function removeAggressiveOutliers(points) {
        if (points.length === 0) return [];
        
        // Create a copy of points
        let cleanedPoints = [...points];
        const heights = points.map(p => p.height);
        
        // Calculate rolling median with smaller window to preserve wave structure
        const windowSize = 7;
        const rollingMedian = calculateRunningMedian(heights, windowSize);
        
        // Identify spikes by comparing with rolling median
        for (let i = 1; i < cleanedPoints.length - 1; i++) {
            const currentHeight = cleanedPoints[i].height;
            const expectedHeight = rollingMedian[i];
            const prevHeight = cleanedPoints[i - 1].height;
            const nextHeight = cleanedPoints[i + 1].height;
            
            // Calculate how much the current point deviates from expected
            const deviation = Math.abs(currentHeight - expectedHeight);
            
            // Calculate local wave pattern
            const prevDiff = Math.abs(currentHeight - prevHeight);
            const nextDiff = Math.abs(currentHeight - nextHeight);
            const localDiff = (prevDiff + nextDiff) / 2;
            
            // Define spike threshold based on gauge
            const gaugeMultiplier = cleanedPoints[i].gauge >= 4 ? 1.5 : 1.0;
            const spikeThreshold = 5 * gaugeMultiplier;
            
            // Check if this is a spike (sudden sharp deviation)
            const isSpike = localDiff > spikeThreshold && deviation > spikeThreshold;
            
            if (isSpike) {
                // Get local trend using wider window
                const localStart = Math.max(0, i - 3);
                const localEnd = Math.min(cleanedPoints.length - 1, i + 3);
                const localHeights = [];
                
                for (let j = localStart; j <= localEnd; j++) {
                    if (j !== i) {
                        localHeights.push(cleanedPoints[j].height);
                    }
                }
                
                // Replace spike with local trend value
                const localMedian = calculateMedian(localHeights);
                cleanedPoints[i].height = localMedian;
            }
        }
        
        // Apply light smoothing only to extreme transitions
        cleanedPoints = applyLightSmoothing(cleanedPoints);
        
        return cleanedPoints;
    }

    // Light smoothing function that preserves wave structure
    function applyLightSmoothing(points) {
        if (points.length < 3) return points;
        
        const smoothed = [...points];
        const heights = points.map(p => p.height);
        
        for (let i = 1; i < points.length - 1; i++) {
            const current = heights[i];
            const prev = heights[i - 1];
            const next = heights[i + 1];
            
            // Calculate gradient (rate of change)
            const gradient1 = Math.abs(current - prev);
            const gradient2 = Math.abs(next - current);
            
            // Only smooth if gradient changes dramatically (spike pattern)
            const gradientChange = Math.abs(gradient1 - gradient2);
            
            if (gradientChange > 10) { // Threshold for gradient change
                // Use weighted average to preserve trend
                smoothed[i].height = (prev * 0.3 + current * 0.4 + next * 0.3);
            }
        }
        
        return smoothed;
    }

    // Remove Outliers Function
    function removeOutliersAndRenderGraphs() {
        const table = document.getElementById("initialization-table");
        if (!table) {
            showNotification("Initialization table not found", "error");
            return;
        }
        
        const rows = table.querySelectorAll("tbody tr");
        if (!rows.length) {
            showNotification("No data in initialization table", "error");
            return;
        }

        const cleanedData = [[], [], [], [], []];

        rows.forEach((row) => {
            for (let i = 0; i < 5; i++) {
                const timeCell = row.cells[i * 2];
                const heightCell = row.cells[i * 2 + 1];
                if (!timeCell || !heightCell) continue;
                const time = parseFloat(timeCell.textContent);
                const height = parseFloat(heightCell.textContent);
                if (!isNaN(time) && !isNaN(height)) {
                    cleanedData[i].push({ time, height });
                }
            }
        });

        // Use the improved outlier removal method
        const cleanedSeries = removeOutliers(cleanedData);
        
        // Create combined data with selective cleaning
        let allPoints = [];
        cleanedSeries.forEach((series, gaugeIndex) => {
            series.forEach(point => {
                allPoints.push({
                    time: point.time,
                    height: point.height,
                    gauge: gaugeIndex + 1
                });
            });
        });
        
        // Sort by time and apply selective outlier removal for combined view
        allPoints.sort((a, b) => a.time - b.time);
        const combinedCleaned = removeAggressiveOutliers(allPoints);

        window.requestAnimationFrame(() => {
            cleanedSeries.forEach((series, i) => {
                const times = series.map(p => p.time);
                const heights = series.map(p => p.height);
                drawChart(
                    `outlier-graph${i + 1}`,
                    `Wave Height${i + 1} (cm) vs Outlier-Removed Time${i + 1} (sec)`,
                    times,
                    heights
                );
            });

            // Use cleaned data for combined graph
            const allTimes = combinedCleaned.map(p => p.time);
            const allHeights = combinedCleaned.map(p => p.height);

            drawChart(
                "outlier-combined-graph",
                "All Wave Heights (cm) vs All Outlier-Removed Times (sec)",
                allTimes,
                allHeights
            );

            // Generate smooth plots
            generateSmoothPlots(cleanedSeries, combinedCleaned);
        });

        showNotification("Outliers removed and graphs updated!");
    }

    // Generate smooth plots
    function generateSmoothPlots(cleanedSeries, combinedCleaned) {
        window.requestAnimationFrame(() => {
            // Create smooth plots for individual sensors
            let smoothedFullData = [];
            
            cleanedSeries.forEach((series, i) => {
                const times = series.map(p => p.time);
                const heights = series.map(p => p.height);
                
                // Apply smoothing
                const smoothedHeights = applySmoothingForSmoothPlot(heights);
                
                // Store smoothed data for range plotting
                smoothedFullData.push({
                    times: times,
                    heights: smoothedHeights,
                    original: series
                });
                
                // Draw individual smooth graphs
                drawSmoothChart(
                    `smooth-graph${i + 1}`,
                    `Smooth Wave Height${i + 1} (cm) vs Time${i + 1} (sec)`,
                    times,
                    smoothedHeights,
                    `rgba(0, 51, 153, 1)` // Deep blue color
                );
            });

            // Create smooth combined plot with all points from cleaned data
            const allTimes = combinedCleaned.map(p => p.time);
            const allHeights = combinedCleaned.map(p => p.height);
            const smoothedAllHeights = applySmoothingForSmoothPlot(allHeights);
            
            // Store smoothed combined data for range plotting
            smoothedDataCache = {
                individual: smoothedFullData,
                combined: {
                    times: allTimes,
                    heights: smoothedAllHeights
                }
            };
            
            // Draw combined smooth graph
            drawCombinedSmoothChart(
                "smooth-combined-graph",
                "Combined Smooth Wave Height vs Time",
                allTimes,
                smoothedAllHeights
            );
        });
    }

    // Get color for each gauge
    function getColorForGauge(index) {
        const colors = [
            'rgba(0, 123, 255, 0.8)',   // Blue
            'rgba(255, 99, 132, 0.8)',  // Red
            'rgba(75, 192, 192, 0.8)',  // Turquoise
            'rgba(255, 159, 64, 0.8)',  // Orange
            'rgba(153, 102, 255, 0.8)'  // Purple
        ];
        return colors[index % colors.length];
    }

    // Draw smooth individual charts
    function drawSmoothChart(canvasId, label, labels, data, color) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.warn(`Canvas element ${canvasId} not found`);
            return;
        }

        const ctx = canvas.getContext("2d");
        if (!ctx) {
            console.warn(`Could not get context for canvas ${canvasId}`);
            return;
        }

        if (canvas.chart) canvas.chart.destroy();

        canvas.chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: [
                    {
                        label: label,
                        data: data,
                        borderColor: color,
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        borderWidth: 0.5,  // Decreased from 1.5
                        pointRadius: 1,    // Decreased from 2
                        fill: false,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: "Time (sec)",
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(200, 200, 200, 0.1)'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: "Wave Height (cm)",
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(200, 200, 200, 0.2)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: {
                                size: 12
                            }
                        }
                    }
                },
                animation: {
                    duration: 0
                }
            }
        });
    }

    // Draw combined smooth chart with all wave data points
    function drawCombinedSmoothChart(canvasId, label, times, heights) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.warn(`Canvas element ${canvasId} not found`);
            return;
        }

        const ctx = canvas.getContext("2d");
        if (!ctx) {
            console.warn(`Could not get context for canvas ${canvasId}`);
            return;
        }

        if (canvas.chart) canvas.chart.destroy();

        canvas.chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: times,
                datasets: [{
                    label: label,
                    data: heights,
                    borderColor: 'rgba(0, 51, 153, 1)', // Deep blue color
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    borderWidth: 0.5,  // Decreased line thickness
                    pointRadius: 1,    // Decreased point size
                    fill: false,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: "Time (sec)",
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(200, 200, 200, 0.1)'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: "Wave Height (cm)",
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(200, 200, 200, 0.2)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            title: function(tooltipItems) {
                                return tooltipItems[0].parsed.x.toFixed(3) + ' sec';
                            },
                            label: function(context) {
                                return 'Height: ' + context.parsed.y.toFixed(2) + ' cm';
                            }
                        }
                    }
                },
                animation: {
                    duration: 0
                }
            }
        });
    }

    // Range Plot Functionality
    document.getElementById("generate-range-btn").addEventListener("click", function() {
        const startTime = parseFloat(document.getElementById("start-time").value);
        const endTime = parseFloat(document.getElementById("end-time").value);
        
        if (isNaN(startTime) || isNaN(endTime)) {
            showNotification("Please enter valid start and end times", "error");
            return;
        }
        
        if (startTime >= endTime) {
            showNotification("Start time must be less than end time", "error");
            return;
        }
        
        if (!smoothedDataCache) {
            showNotification("Please load and process initialization data first", "error");
            return;
        }
        
        generateRangePlots(startTime, endTime);
    });

    function generateRangePlots(startTime, endTime) {
        const individual = smoothedDataCache.individual;
        const combined = smoothedDataCache.combined;
        
        // Filter data for individual plots
        individual.forEach((data, index) => {
            const filteredTimes = [];
            const filteredHeights = [];
            
            data.times.forEach((time, i) => {
                if (time >= startTime && time <= endTime) {
                    filteredTimes.push(time);
                    filteredHeights.push(data.heights[i]);
                }
            });
            
            // Draw individual range graphs
            drawSmoothChart(
                `range-graph${index + 1}`,
                `Range Wave Height${index + 1} (cm) vs Time${index + 1} (sec)`,
                filteredTimes,
                filteredHeights,
                `rgba(0, 51, 153, 1)` // Deep blue color
            );
        });
        
        // Filter data for combined plot
        const filteredCombinedTimes = [];
        const filteredCombinedHeights = [];
        
        combined.times.forEach((time, i) => {
            if (time >= startTime && time <= endTime) {
                filteredCombinedTimes.push(time);
                filteredCombinedHeights.push(combined.heights[i]);
            }
        });
        
        // Draw combined range graph
        drawCombinedSmoothChart(
            "range-combined-graph",
            `Combined Range Wave Height vs Time (${startTime}s - ${endTime}s)`,
            filteredCombinedTimes,
            filteredCombinedHeights
        );
        
        showNotification(`Range plots generated for ${startTime}s to ${endTime}s`);
    }

    // Outlier Stats Functions
    function removeOutliers(data) {
        const cleanedData = [];
        
        data.forEach((seriesData, seriesIndex) => {
            const series = [...seriesData];
            const heights = series.map(p => p.height);
            
            // Calculate baseline stats
            const median_val = calculateMedian(heights);
            const q1 = percentile(heights, 25);
            const q3 = percentile(heights, 75);
            const iqr = q3 - q1;
            
            // Running median with adaptive window
            const windowSize = Math.min(11, Math.max(5, Math.floor(heights.length / 100)));
            const runningMedian = calculateRunningMedian(heights, windowSize);
            
            // Gauge-specific sensitivity
            const sensitivity = {
                0: 20,  // Gauge 1 (most stable)
                1: 20,  // Gauge 2 (stable)
                2: 20,  // Gauge 3 (stable)
                3: 35,  // Gauge 4 (has large spikes)
                4: 35   // Gauge 5 (has large spikes)
            };
            
            const baseThreshold = sensitivity[seriesIndex] || 25;
            
            // Clean the data
            for (let i = 0; i < series.length; i++) {
                const height = series[i].height;
                const expectedHeight = runningMedian[i];
                const deviation = Math.abs(height - expectedHeight);
                
                // Dynamic threshold based on local volatility
                let threshold = baseThreshold;
                
                // Increase threshold in volatile regions
                if (i > 5 && i < series.length - 5) {
                    const localWindow = heights.slice(i - 5, i + 5);
                    const localStd = calculateStandardDeviation(localWindow, calculateMean(localWindow));
                    if (localStd > 5) {
                        threshold *= 1.3;
                    }
                }
                
                // Check if this is an outlier
                if (deviation > threshold) {
                    let replacement = expectedHeight;
                    
                    // For extreme outliers, check adjacent points
                    if (deviation > threshold * 2) {
                        // Find nearest non-outlier neighbors
                        let prevValid = expectedHeight;
                        let nextValid = expectedHeight;
                        
                        for (let j = i - 1; j >= 0; j--) {
                            if (Math.abs(series[j].height - runningMedian[j]) <= threshold) {
                                prevValid = series[j].height;
                                break;
                            }
                        }
                        
                        for (let j = i + 1; j < series.length; j++) {
                            if (Math.abs(series[j].height - runningMedian[j]) <= threshold) {
                                nextValid = series[j].height;
                                break;
                            }
                        }
                        
                        replacement = (prevValid + nextValid) / 2;
                    }
                    
                    series[i].height = replacement;
                }
            }
            
            // Apply secondary smoothing only to extreme outliers
            const finalSeries = secondarySmoothing(series);
            cleanedData.push(finalSeries);
        });
        
        return cleanedData;
    }
    
    function calculateRunningMedian(values, windowSize) {
        const result = [];
        const halfWindow = Math.floor(windowSize / 2);
        
        for (let i = 0; i < values.length; i++) {
            const start = Math.max(0, i - halfWindow);
            const end = Math.min(values.length - 1, i + halfWindow);
            const window = values.slice(start, end + 1);
            result.push(calculateMedian(window));
        }
        
        return result;
    }
    
    function secondarySmoothing(series) {
        const smoothed = [...series];
        const heights = series.map(p => p.height);
        
        for (let i = 1; i < series.length - 1; i++) {
            const current = heights[i];
            const prev = heights[i - 1];
            const next = heights[i + 1];
            
            // Only smooth if current point is significantly different from both neighbors
            const diffPrev = Math.abs(current - prev);
            const diffNext = Math.abs(current - next);
            const avgDiff = (diffPrev + diffNext) / 2;
            
            if (avgDiff > 15) { // Threshold for secondary smoothing
                smoothed[i].height = (prev + next) / 2;
            }
        }
        
        return smoothed;
    }

    function calculateMean(values) {
        if (!values || values.length === 0) return 0;
        const sum = values.reduce((a, b) => a + b, 0);
        return sum / values.length;
    }

    function calculateStandardDeviation(values, mean) {
        if (!values || values.length === 0) return 0;
        const squaredDiffs = values.map(value => Math.pow(value - mean, 2));
        const avgSquaredDiff = calculateMean(squaredDiffs);
        return Math.sqrt(avgSquaredDiff);
    }

    function calculateMedian(values) {
        if (!values || values.length === 0) return 0;
        const sorted = [...values].sort((a, b) => a - b);
        const middle = Math.floor(sorted.length / 2);
        if (sorted.length % 2 === 0) {
            return (sorted[middle - 1] + sorted[middle]) / 2;
        } else {
            return sorted[middle];
        }
    }
    
    function percentile(values, p) {
        if (!values || values.length === 0) return 0;
        const sorted = [...values].sort((a, b) => a - b);
        const index = (p / 100) * (sorted.length - 1);
        const lower = Math.floor(index);
        const upper = Math.ceil(index);
        
        if (lower === upper) return sorted[lower];
        return sorted[lower] + (sorted[upper] - sorted[lower]) * (index - lower);
    }

    function applyMovingAverage(values, windowSize) {
        if (!values || values.length === 0) return [];
        const smoothed = [];
        const halfWindow = Math.floor(windowSize / 2);

        for (let i = 0; i < values.length; i++) {
            const start = Math.max(i - halfWindow, 0);
            const end = Math.min(i + halfWindow, values.length - 1);
            const window = values.slice(start, end + 1);
            smoothed.push(calculateMean(window));
        }

        return smoothed;
    }

    // Modified chart drawing function to better show wave patterns with decreased line thickness
    function drawChart(canvasId, label, labels, data) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.warn(`Canvas element ${canvasId} not found`);
            return;
        }

        const ctx = canvas.getContext("2d");
        if (!ctx) {
            console.warn(`Could not get context for canvas ${canvasId}`);
            return;
        }

        if (canvas.chart) canvas.chart.destroy();

        canvas.chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: labels,
                datasets: [
                    {
                        label: label,
                        data: data,
                        borderColor: "blue",
                        backgroundColor: "rgba(0, 0, 0, 0)",
                        borderWidth: 0.5,  // Decreased from 1.5
                        pointRadius: 1,    // Decreased from 2
                        pointBackgroundColor: 'blue',
                        pointBorderColor: 'blue',
                        fill: false,
                        tension: 0.1, // Moderate tension to maintain wave pattern
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: "Time (sec)",
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(200, 200, 200, 0.1)'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: "Wave Height (cm)",
                            font: {
                                size: 14
                            }
                        },
                        grid: {
                            display: true,
                            color: 'rgba(200, 200, 200, 0.2)'
                        },
                        // Set y-axis range to better show wave variations
                        min: Math.floor(Math.min(...data) - 5),
                        max: Math.ceil(Math.max(...data) + 5)
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        enabled: true,
                        mode: 'nearest',
                        intersect: false,
                        callbacks: {
                            title: function(tooltipItems) {
                                return `Time: ${tooltipItems[0].parsed.x.toFixed(3)} sec`;
                            },
                            label: function(context) {
                                return `Height: ${context.parsed.y.toFixed(2)} cm`;
                            }
                        }
                    }
                },
                animation: {
                    duration: 0 // Disable animations for better performance
                }
            }
        });
    }

    // Download Graph Functionality
    document.getElementById("download-selected-graphs").addEventListener("click", function() {
        const selectedCheckboxes = document.querySelectorAll('.checkbox-group input[type="checkbox"]:checked');
        
        if (selectedCheckboxes.length === 0) {
            showNotification("Please select at least one graph to download", "error");
            return;
        }

        selectedCheckboxes.forEach(checkbox => {
            const value = checkbox.value;
            
            switch(value) {
                case 'wave-gauge-ms':
                    downloadGraphSet(['graph1', 'graph2', 'graph3', 'graph4', 'graph5']);
                    break;
                case 'wave-gauge-sec':
                    downloadGraphSet(['graph6', 'graph7', 'graph8', 'graph9', 'graph10']);
                    break;
                case 'initialization':
                    downloadGraphSet(['initialization-graph1', 'initialization-graph2', 'initialization-graph3', 'initialization-graph4', 'initialization-graph5']);
                    break;
                case 'outlier-removed':
                    downloadGraphSet(['outlier-graph1', 'outlier-graph2', 'outlier-graph3', 'outlier-graph4', 'outlier-graph5']);
                    break;
                case 'combined-outlier':
                    downloadGraph('outlier-combined-graph');
                    break;
                case 'smooth-individual':
                    downloadGraphSet(['smooth-graph1', 'smooth-graph2', 'smooth-graph3', 'smooth-graph4', 'smooth-graph5']);
                    break;
                case 'smooth-combined':
                    downloadGraph('smooth-combined-graph');
                    break;
                case 'range-individual':
                    downloadGraphSet(['range-graph1', 'range-graph2', 'range-graph3', 'range-graph4', 'range-graph5']);
                    break;
                case 'range-combined':
                    downloadGraph('range-combined-graph');
                    break;
            }
        });

        showNotification("Selected graphs downloaded successfully!");
    });

    function downloadGraph(canvasId) {
        const canvas = document.getElementById(canvasId);
        if (!canvas || !canvas.chart) {
            console.warn(`Canvas ${canvasId} not found or has no chart`);
            return;
        }

        // Get the chart title as filename
        const title = canvas.chart.config.options.plugins?.title?.text || 
                     canvas.chart.config.data.datasets[0].label || 
                     canvasId;
        
        // Clean the title to make it a valid filename
        const filename = title.replace(/[^a-z0-9]/gi, '_').toLowerCase() + '.png';

        // Create a temporary canvas with white background
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const tempCtx = tempCanvas.getContext('2d');
        
        // Fill with white background
        tempCtx.fillStyle = 'white';
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        
        // Draw the chart on top of the white background
        tempCtx.drawImage(canvas, 0, 0);

        // Create a download link
        const link = document.createElement('a');
        link.download = filename;
        link.href = tempCanvas.toDataURL('image/png');
        link.click();
    }

    function downloadGraphSet(canvasIds) {
        canvasIds.forEach(canvasId => {
            downloadGraph(canvasId);
        });
    }

    // Button Event Listeners
    document.getElementById("toggle-initialization-table").addEventListener("click", function () {
        const table = document.getElementById("initialization-table-wrapper");
        table.style.display = (table.style.display === "none" || table.style.display === "") ? "block" : "none";
    });
    
    // Delete File Button
    document.getElementById("delete-file-btn").addEventListener("click", function () {
        const fileInput = document.getElementById("project-directory");
        fileInput.value = ""; // Clear the file input
        showNotification("File deleted successfully!");
    });
        
        // Debug: List all elements with IDs to help identify any issues
        console.log("Elements with IDs found:", Array.from(document.querySelectorAll('[id]')).map(el => el.id));
    }, 100); // Add 100ms delay to ensure DOM is fully ready
});